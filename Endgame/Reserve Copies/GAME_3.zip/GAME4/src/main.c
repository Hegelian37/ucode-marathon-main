#include "header.h"

void handleInput(SDL_Event* event, int* quit) {
	while (SDL_PollEvent(event) != 0) {
		if (event->type == SDL_QUIT) {
			*quit = 1;
		}
	}

	const Uint8* currentKeyStates = SDL_GetKeyboardState(NULL);

	if (currentKeyStates[SDL_SCANCODE_ESCAPE]) {
		*quit = 1;
	}

	if (currentKeyStates[SDL_SCANCODE_RIGHT]) {
		if (backgroundRect.x > SCREEN_WIDTH - BG_WIDTH + PLAYER_WIDTH / 2 && playerRect.x  == SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2) {
		backgroundRect.x -= PLAYER_SPEED;
		} else if (playerRect.x < SCREEN_WIDTH - PLAYER_WIDTH) {
			playerRect.x += PLAYER_SPEED;
		}
	}

	if (currentKeyStates[SDL_SCANCODE_LEFT]) {
		if (backgroundRect.x < 0 && playerRect.x == SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2) {
		backgroundRect.x += PLAYER_SPEED;
		} else if (playerRect.x > 0) {
			playerRect.x -= PLAYER_SPEED;
		}
	}
}

void updateGame() {
	// Update game logic here
}

int main() {
	if (!initializeSDL()) {
		return 1;
	}

	// Load player texture
	playerTexture = loadTexture("resources/textures/char.png");
	if (playerTexture == NULL) {
		closeSDL();
		return 1;
	}

	backgroundTexture = loadTexture("resources/images/bg.bmp");
	if (backgroundTexture == NULL) {
		closeSDL();
		return 1;
	}

	int quit = 0;
	SDL_Event e;

	// Initialize player position
	playerRect.x = SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2;
	playerRect.y = SCREEN_HEIGHT - PLAYER_HEIGHT;
	playerRect.w = PLAYER_WIDTH;
	playerRect.h = PLAYER_HEIGHT;

	backgroundRect.x = 0;
	backgroundRect.y = 0;
	backgroundRect.w = BG_WIDTH;
	backgroundRect.h = SCREEN_HEIGHT;

	while (!quit) {
		handleInput(&e, &quit);
		updateGame();
		render();
	}

	closeSDL();
	return 0;
}

