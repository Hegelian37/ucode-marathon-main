#include "header.h"

void help_screen() {
	SDL_RenderClear(renderer);
	backgroundTexture = loadTexture("resources/textures/help_screen.png");
	
}

