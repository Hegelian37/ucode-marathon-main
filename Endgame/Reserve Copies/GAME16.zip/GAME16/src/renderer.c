#include "header.h"

void render() {
	// Clear the renderer
	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
	SDL_RenderClear(renderer);
	SDL_Delay(5);
	
	SDL_RenderCopy(renderer, backgroundTexture, NULL, &backgroundRect);
	SDL_RenderCopy(renderer, DoorTexture, &animationClipsDoor[currentFrameDoor], &DoorRect);
	SDL_RenderCopy(renderer, playerTexture, &animationClipsPlayer[currentFramePlayer], &playerRect);

	// Present the renderer
	SDL_RenderPresent(renderer);
}

