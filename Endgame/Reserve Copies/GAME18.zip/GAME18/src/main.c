#include "header.h"

int LEVEL = 0;
int currentBg = 0;

int main() {
	if (!initializeSDL()) {
		return 1;
	}
	
	Resolution resolutions[NUM_RESOLUTIONS];
	arrinit(resolutions);

	int resol_count = 4;

	adapUI(resol_count, resolutions);

	if (resol_count == 0)
	{
		SDL_SetWindowFullscreen(window, SDL_WINDOW_FULLSCREEN);
	}
	
	switch (showmenu()) {
		case 0:
			loc_room_day();
			break;
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			closeSDL();
			break;
	}
	
	closeSDL();
	return 0;
}

