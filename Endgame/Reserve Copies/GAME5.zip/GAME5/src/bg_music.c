#include "header.h"

void bg_music(char *href)
{
	backgroundMusic = Mix_LoadMUS(href);
	if (backgroundMusic == NULL) {
		printf("Failed to load background music! SDL_mixer Error: %s\n", Mix_GetError());
		//return 1;
	}

	// Воспроизведение музыки на фоне
	Mix_PlayMusic(backgroundMusic, -1);
}

