#include "header.h"

int settings() {
	int x, y;
	int NUMMENU = 3;
	SDL_Texture* button[3];
	SDL_Rect pos[3];
	bool selected[3] = { 0, 0, 0};
	char* unclickpath[] = { "resources/textures/buttons/settings/screen/purple/screen426.png", "resources/textures/buttons/settings/music_v/purple/music_volume_0.png", "resources/textures/buttons/menu/purple/loadgame_button.png" };
	char* clickpath[] = { "resources/textures/buttons/settings/screen/grey/screen426.png", "resources/textures/buttons/settings/music_v/grey/music_volume_0.png", "resources/textures/buttons/menu/grey/loadgame_button.png" };
	SDL_RenderClear(renderer);
	for (int i = 0; i < NUMMENU; i++) {
		button[i] = loadTexture(unclickpath[i]);
		pos[i].h = 2 * (SCREEN_HEIGHT / 4) / NUMMENU;
		pos[i].w = 536 * pos[i].h / 200;
		pos[i].x = SCREEN_WIDTH / 2 - pos[i].w / 2;
		if (i == 0) {
			pos[i].y = SCREEN_HEIGHT / 3 - pos[i].h / 2;
		}
		else {
			pos[i].y = pos[i - 1].y + 5 * pos[i - 1].h / 4;
		}
	}
	SDL_Event event;
	while (1) {
		while (SDL_PollEvent(&event))
		{
			switch (event.type)
			{
				case SDL_QUIT:
					SDL_RenderClear(renderer);
					closeSDL();
					return 1;
				case SDL_MOUSEMOTION:
					x = event.motion.x;
					y = event.motion.y;
					for (int i = 0; i < NUMMENU; i += 1) {
						if (x >= pos[i].x && x <= pos[i].x + pos[i].w && y >= pos[i].y && y <= pos[i].y + pos[i].h)
						{
							if (!selected[i])
							{
								selected[i] = 1;
								SDL_RenderClear(renderer);
								SDL_DestroyTexture(button[i]);
								button[i] = loadTexture(clickpath[i]);
							}
						}
						else
						{
							if (selected[i])
							{
								selected[i] = 0;
								SDL_RenderClear(renderer);
								SDL_DestroyTexture(button[i]);
								button[i] = loadTexture(unclickpath[i]);
							}
						}
					}
					break;
				case SDL_MOUSEBUTTONDOWN:
					x = event.button.x;
					y = event.button.y;
					for (int i = 0; i < NUMMENU; i += 1) {
						if (x >= pos[i].x && x <= pos[i].x + pos[i].w && y >= pos[i].y && y <= pos[i].y + pos[i].h)
						{
							for (int i = 0; i < NUMMENU; i += 1) {
								SDL_DestroyTexture(button[i]);
							}
							//SDL_DestroyTexture(backgroundTexture);
							SDL_RenderClear(renderer);
							return i;
						}
					}
					break;
				case SDL_KEYDOWN:
					SDL_RenderClear(renderer);
					if (event.key.keysym.sym == SDLK_ESCAPE) {
						return 0;
					}
			}
		}
		SDL_RenderCopy(renderer, backgroundTexture, NULL, &backgroundRect);
		for (int i = 0; i < NUMMENU; i += 1) {
			SDL_RenderCopy(renderer, button[i], NULL, &pos[i]);
		}
		SDL_RenderPresent(renderer);
	}
}

