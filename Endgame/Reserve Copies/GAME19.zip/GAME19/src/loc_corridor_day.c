#include "header.h"

int loc_corridor_day() {
	bg_music("resources/sounds/mainmenu.mp3", 0.5);

	// Load player texture
	playerTexture = loadTexture("resources/textures/sprites/main_walk_8fr.png");
	if (playerTexture == NULL) {
		closeSDL();
		SDL_Quit();
		return 1;
	}
	
	backgroundTexture = loadTexture("resources/textures/backgrounds/bg_corridor.bmp");
	if (backgroundTexture == NULL) {
		closeSDL();
		SDL_Quit();
		return 1;
	}
	currentBg = 2;
	
	DoorTexture = loadTexture("resources/textures/sprites/door_open_2fr.png");

	/*int quit = 0;
	SDL_Event e;*/

	// Initialize player position
	playerRect.x = 300;
	playerRect.y = SCREEN_HEIGHT - PLAYER_HEIGHT;
	playerRect.w = PLAYER_WIDTH;
	playerRect.h = PLAYER_HEIGHT;
	
	int frameWidthPlayer = 60;
	int frameHeightPlayer = 60;
	for (int i = 0; i < NUM_FRAMES_PLAYER; ++i) {
		animationClipsPlayer[i].x = i * frameWidthPlayer;
		animationClipsPlayer[i].y = 0;
		animationClipsPlayer[i].w = frameWidthPlayer;
		animationClipsPlayer[i].h = frameHeightPlayer;
	}
	
	CorrRoomDoorRect.x = 300;
	CorrRoomDoorRect.y = SCREEN_HEIGHT - DOOR_HEIGHT;
	CorrRoomDoorRect.w = DOOR_WIDTH;
	CorrRoomDoorRect.h = DOOR_HEIGHT;
	
	MessDoorRect.x = SCREEN_WIDTH + 200;
	MessDoorRect.y = SCREEN_HEIGHT - DOOR_HEIGHT;
	MessDoorRect.w = DOOR_WIDTH;
	MessDoorRect.h = DOOR_HEIGHT;
	
	OutDoorRect.x = SCREEN_WIDTH;
	OutDoorRect.y = SCREEN_HEIGHT - DOOR_HEIGHT;
	OutDoorRect.w = DOOR_WIDTH;
	OutDoorRect.h = DOOR_HEIGHT;

	int frameWidthDoor = 134;
	int frameHeightDoor = 242;
	for (int i = 0; i < NUM_FRAMES_DOOR; ++i) {
		animationClipsDoor[i].x = i * frameWidthDoor;
		animationClipsDoor[i].y = 0;
		animationClipsDoor[i].w = frameWidthDoor;
		animationClipsDoor[i].h = frameHeightDoor;
	}
	
	backgroundRect.x = -700;
	backgroundRect.y = 0;
	backgroundRect.w = BG_WIDTH;
	backgroundRect.h = SCREEN_HEIGHT;

	handleInput();
	
	/*int mouseX, mouseY;
	while (!quit) {
		
		handleInput(&e, &quit);
		render();
	}*/
		
	closeSDL();
	return 0;
}

