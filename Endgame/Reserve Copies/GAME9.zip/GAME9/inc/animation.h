#ifndef ANIMATION_H
#define ANIMATION_H

extern int currentFrame;
extern int frameCounter;
extern SDL_Rect animationClips[];

#endif
