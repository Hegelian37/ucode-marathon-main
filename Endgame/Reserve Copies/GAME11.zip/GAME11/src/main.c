#include "header.h"

int main() {
	if (!initializeSDL()) {
		return 1;
	}
	
	showmenu();
	
	closeSDL();
	return 0;
}

