#include "header.h"
#include "animation.h"

int currentFrame = 0;
int frameCounter = 0;

void handleInput(SDL_Event* event, int* quit) {
	while (SDL_PollEvent(event) != 0) {
		if (event->type == SDL_QUIT) {
			*quit = 1;
		} else if (event->type == SDL_MOUSEMOTION) {
			int mouseX, mouseY;
			SDL_GetMouseState(&mouseX, &mouseY);

			// Check if the mouse is over the object
			if (isMouseOver(&objDoorRect, mouseX, mouseY)) {
				// Change the object texture when the mouse is over
				SDL_RenderCopy(renderer, objDoorAjarTexture, NULL, &objDoorRect);
			} else {
				// Render the object with the initial texture
				SDL_RenderCopy(renderer, objDoorTexture, NULL, &objDoorRect);
			}
		}
	}

	const Uint8* currentKeyStates = SDL_GetKeyboardState(NULL);

	if (currentKeyStates[SDL_SCANCODE_ESCAPE]) {
		*quit = 1;
		closeSDL();
	}
	
	if (currentKeyStates[SDL_SCANCODE_LEFT]) {	
		if (backgroundRect.x < 0 && playerRect.x == SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2 && playerRect.x == SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2) {
		backgroundRect.x += PLAYER_SPEED;
		objDoorRect.x += PLAYER_SPEED;
		} else if (playerRect.x > 0) {
			playerRect.x -= PLAYER_SPEED;
		}
		// Update animation frame
		frameCounter++;
		if (frameCounter >= FRAME_DELAY) {
			currentFrame = (currentFrame + 1) % 3 + 4;
			frameCounter = 0;
		}
	} else if (currentKeyStates[SDL_SCANCODE_RIGHT]) {
		if (backgroundRect.x > SCREEN_WIDTH - BG_WIDTH + PLAYER_WIDTH / 2 && playerRect.x == SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2) {
		backgroundRect.x -= PLAYER_SPEED;
		objDoorRect.x -= PLAYER_SPEED;
		} else if (playerRect.x < SCREEN_WIDTH - PLAYER_WIDTH) {
			playerRect.x += PLAYER_SPEED;
		}
		// Update animation frame
		frameCounter++;
		if (frameCounter >= FRAME_DELAY) {
			currentFrame = (currentFrame + 1) % 3 + 1;
			frameCounter = 0;
		}
	} else {
		currentFrame = 0;
	}
}

