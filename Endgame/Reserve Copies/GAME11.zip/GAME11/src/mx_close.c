#include "header.h"

void closeSDL() {
	SDL_DestroyTexture(playerTexture);
	SDL_DestroyTexture(objDoorTexture);
	SDL_DestroyTexture(objDoorAjarTexture);
	SDL_DestroyTexture(backgroundTexture);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	IMG_Quit();
	SDL_Quit();
	exit(0);
}

