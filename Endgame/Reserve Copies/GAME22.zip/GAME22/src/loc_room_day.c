#include "header.h"

int loc_room_day() {
	int DEV = 0;
	bg_music("resources/sounds/mainmenu.mp3", 0.5);

	// Load player texture
	playerTexture = loadTexture("resources/textures/sprites/main_walk_8fr.png");
	if (playerTexture == NULL) {
		closeSDL();
		SDL_Quit();
		return 1;
	}
	
	backgroundTexture = loadTexture("resources/textures/backgrounds/bg.bmp");
	if (backgroundTexture == NULL) {
		closeSDL();
		SDL_Quit();
		return 1;
	}
	currentBg = 1;
	
	DoorTexture = loadTexture("resources/textures/sprites/door_open_2fr.png");

	/*int quit = 0;
	SDL_Event e;*/

	// Initialize player position
	playerRect.x = SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2;
	playerRect.y = SCREEN_HEIGHT - PLAYER_HEIGHT;
	playerRect.w = PLAYER_WIDTH;
	playerRect.h = PLAYER_HEIGHT;
	
	int frameWidthPlayer = 60;
	int frameHeightPlayer = 60;
	for (int i = 0; i < NUM_FRAMES_PLAYER; ++i) {
		animationClipsPlayer[i].x = i * frameWidthPlayer;
		animationClipsPlayer[i].y = 0;
		animationClipsPlayer[i].w = frameWidthPlayer;
		animationClipsPlayer[i].h = frameHeightPlayer;
	}
	
	if (PREV_LEVEL == 1) DEV = SCREEN_WIDTH / 2 + PLAYER_WIDTH / 2;
	else DEV = 0;
	
	RoomDoorRect.x = SCREEN_WIDTH - DEV;
	RoomDoorRect.y = SCREEN_HEIGHT - DOOR_HEIGHT;
	RoomDoorRect.w = DOOR_WIDTH;
	RoomDoorRect.h = DOOR_HEIGHT;

	int frameWidthDoor = 134;
	int frameHeightDoor = 242;
	for (int i = 0; i < NUM_FRAMES_DOOR; ++i) {
		animationClipsDoor[i].x = i * frameWidthDoor;
		animationClipsDoor[i].y = 0;
		animationClipsDoor[i].w = frameWidthDoor;
		animationClipsDoor[i].h = frameHeightDoor;
	}
	
	backgroundRect.x = -SCREEN_WIDTH - DEV;
	backgroundRect.y = 0;
	backgroundRect.w = BG_WIDTH;
	backgroundRect.h = SCREEN_HEIGHT;
	
	eTexture = loadTexture("resources/e.png");
	eRect.x = RoomDoorRect.x + RoomDoorRect.w / 2;
	eRect.y = RoomDoorRect.y - 10;
	eRect.w = 40;
	eRect.h = 40;

	handleInput();
	
	/*int mouseX, mouseY;
	while (!quit) {
		
		handleInput(&e, &quit);
		render();
	}*/
		
	closeSDL();
	return 0;
}

