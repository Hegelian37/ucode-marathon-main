#include "header.h"

int loc_outdoors_day() {
	bg_music("resources/sounds/mainmenu.mp3", 0.5);

	// Load player texture
	playerTexture = loadTexture("resources/textures/sprites/main_walk_8fr.png");
	if (playerTexture == NULL) {
		closeSDL();
		SDL_Quit();
		return 1;
	}
	
	backgroundTexture = loadTexture("resources/textures/backgrounds/bg_outdoors.bmp");
	if (backgroundTexture == NULL) {
		closeSDL();
		SDL_Quit();
		return 1;
	}
	currentBg = 4;
	
	DoorTexture = loadTexture("resources/textures/sprites/door_open_2fr.png");

	/*int quit = 0;
	SDL_Event e;*/

	// Initialize player position
	playerRect.x = SCREEN_WIDTH / 2 - PLAYER_HEIGHT / 2;
	playerRect.y = SCREEN_HEIGHT - PLAYER_HEIGHT;
	playerRect.w = PLAYER_WIDTH;
	playerRect.h = PLAYER_HEIGHT;
	
	int frameWidthPlayer = 60;
	int frameHeightPlayer = 60;
	for (int i = 0; i < NUM_FRAMES_PLAYER; ++i) {
		animationClipsPlayer[i].x = i * frameWidthPlayer;
		animationClipsPlayer[i].y = 0;
		animationClipsPlayer[i].w = frameWidthPlayer;
		animationClipsPlayer[i].h = frameHeightPlayer;
	}
	
	InDoorRect.x = SCREEN_WIDTH / 2 - PLAYER_HEIGHT / 2;
	InDoorRect.y = SCREEN_HEIGHT - DOOR_HEIGHT;
	InDoorRect.w = DOOR_WIDTH;
	InDoorRect.h = DOOR_HEIGHT;

	int frameWidthDoor = 134;
	int frameHeightDoor = 242;
	for (int i = 0; i < NUM_FRAMES_DOOR; ++i) {
		animationClipsDoor[i].x = i * frameWidthDoor;
		animationClipsDoor[i].y = 0;
		animationClipsDoor[i].w = frameWidthDoor;
		animationClipsDoor[i].h = frameHeightDoor;
	}
	
	backgroundRect.x = -SCREEN_WIDTH;
	backgroundRect.y = 0;
	backgroundRect.w = BG_WIDTH;
	backgroundRect.h = SCREEN_HEIGHT;

	handleInput();
	
	/*int mouseX, mouseY;
	while (!quit) {
		
		handleInput(&e, &quit);
		render();
	}*/
		
	closeSDL();
	return 0;
}

