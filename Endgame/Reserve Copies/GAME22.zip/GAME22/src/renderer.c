#include "header.h"

void render() {
	// Clear the renderer
	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
	SDL_RenderClear(renderer);
	SDL_Delay(5);
	
	SDL_RenderCopy(renderer, backgroundTexture, NULL, &backgroundRect);
	if (currentBg == 1) SDL_RenderCopy(renderer, DoorTexture, &animationClipsDoor[currentFrameDoor], &RoomDoorRect);
	if (currentBg == 2) {
		SDL_RenderCopy(renderer, DoorTexture, &animationClipsDoor[currentFrameDoor], &CorrRoomDoorRect);
		SDL_RenderCopy(renderer, DoorTexture, &animationClipsDoor[currentFrameDoor], &MessDoorRect);
		SDL_RenderCopy(renderer, DoorTexture, &animationClipsDoor[currentFrameDoor], &OutDoorRect);
	}
	if (currentBg == 3) SDL_RenderCopy(renderer, DoorTexture, &animationClipsDoor[currentFrameDoor], &CorrDoorRect);
	if (currentBg == 4) SDL_RenderCopy(renderer, DoorTexture, &animationClipsDoor[currentFrameDoor], &InDoorRect);
	SDL_RenderCopy(renderer, playerTexture, &animationClipsPlayer[currentFramePlayer], &playerRect);

	// Present the renderer
	SDL_RenderPresent(renderer);
}

