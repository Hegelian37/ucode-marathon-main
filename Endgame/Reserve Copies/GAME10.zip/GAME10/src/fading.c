#include "header.h"

//SDL_Texture *imageTexture = NULL;

void fading() {
	// Clear the renderer
	SDL_RenderClear(renderer);

	backgroundTexture = loadTexture("resources/textures/backgrounds/start_background.png");
	
	Uint8 alpha = 255; // Initial alpha value (fully opaque)
	//SDL_SetTextureBlendMode(backgroundTexture, SDL_BLENDMODE_BLEND); // Set blend mode for transparency

	// Set the draw color to black (background color)
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderClear(renderer);

	// Draw the image texture with fading effect
	SDL_SetTextureAlphaMod(backgroundTexture, alpha);
	SDL_RenderCopy(renderer, backgroundTexture, NULL, NULL);

	// Gradually reduce alpha (fading effect)
	if (alpha > 0) {
		alpha -= 20; // Adjust the fading speed as needed
	}

	// Delay to control frame rate
	SDL_Delay(1500);
}

