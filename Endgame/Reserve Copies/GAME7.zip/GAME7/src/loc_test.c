#include "header.h"

int loc_test() {

	// Load player texture
	playerTexture = loadTexture("resources/textures/characters/MainCharacter.png");
	if (playerTexture == NULL) {
		closeSDL();
		return 1;
	}

	backgroundTexture = loadTexture("resources/textures/backgrounds/bg.bmp");
	if (backgroundTexture == NULL) {
		closeSDL();
		return 1;
	}

	int quit = 0;
	SDL_Event e;

	// Initialize player position
	playerRect.x = SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2;
	playerRect.y = SCREEN_HEIGHT - PLAYER_HEIGHT;
	playerRect.w = PLAYER_WIDTH;
	playerRect.h = PLAYER_HEIGHT;
	
	// Create clips for each frame
	int frameWidth = 60;
	int frameHeight = 60;
	for (int i = 0; i < NUM_FRAMES; ++i) {
		animationClips[i].x = i * frameWidth;
		animationClips[i].y = 0;
		animationClips[i].w = frameWidth;
		animationClips[i].h = frameHeight;
	}

	backgroundRect.x = 0;
	backgroundRect.y = 0;
	backgroundRect.w = BG_WIDTH;
	backgroundRect.h = SCREEN_HEIGHT;
	
	while (!quit) {
		handleInput(&e, &quit);
		render();
	}
	
	return 0;
}

