#include "header.h"

void render() {
	// Clear the renderer
	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
	SDL_RenderClear(renderer);
	SDL_Delay(5);
	// Render the player texture
	SDL_RenderCopy(renderer, backgroundTexture, NULL, &backgroundRect);
	SDL_RenderCopy(renderer, playerTexture, &animationClips[currentFrame], &playerRect);

	// Present the renderer
	SDL_RenderPresent(renderer);
}

