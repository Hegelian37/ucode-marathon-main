#pragma once

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdbool.h>
#include "animation.h"

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define PLAYER_WIDTH 200
#define PLAYER_HEIGHT 200
#define DOOR_WIDTH 200
#define DOOR_HEIGHT 200
#define PLAYER_SPEED 5
#define NUM_FRAMES 8
#define FRAME_DELAY 10
#define BG_WIDTH 2200

extern SDL_Window* window;

extern SDL_Renderer* renderer;

extern SDL_Rect backgroundRect;
extern SDL_Rect DoorRect;
extern SDL_Rect playerRect;

extern SDL_Texture* backgroundTexture;
extern SDL_Texture* DoorTexture;
extern SDL_Texture* playerTexture;

extern Mix_Chunk* sound;
extern Mix_Music* backgroundMusic;

int initializeSDL();
SDL_Texture* loadTexture(const char* path);
void closeSDL();
void render();
void sound_play(char *href, int volume);
void bg_music(char *href, double volume);
void handleInput();
bool isMouseOver(SDL_Rect* rect, int mouseX, int mouseY);
int showmenu();
void fading();
int loc_room();

