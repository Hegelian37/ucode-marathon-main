#include "header.h"

int main() {
	if (!initializeSDL()) {
		return 1;
	}
	
	switch (showmenu()) {
		case 0:
			loc_room();
			break;
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
	}
	
	closeSDL();
	return 0;
}

