#pragma once

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>
#include <math.h>
#include "animation.h"

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define PLAYER_WIDTH 200
#define PLAYER_HEIGHT 200
#define PLAYER_SPEED 5
#define NUM_FRAMES 8
#define FRAME_DELAY 10
#define BG_WIDTH 1757

extern SDL_Window* window;
extern SDL_Renderer* renderer;
extern SDL_Texture* playerTexture;
extern SDL_Rect playerRect;
extern SDL_Texture* backgroundTexture;
extern SDL_Rect backgroundRect;
extern Mix_Chunk* sound;
extern Mix_Music* backgroundMusic;

extern SDL_Window* window;
extern SDL_Renderer* renderer;
extern SDL_Texture* playerTexture;
extern SDL_Rect playerRect;
extern SDL_Texture* backgroundTexture;
extern SDL_Rect backgroundRect;
extern Mix_Chunk* sound;
extern Mix_Music* backgroundMusic;

int initializeSDL();
SDL_Texture* loadTexture(const char* path);
void closeSDL();
void render();
void sound_play(char *href, int volume);
void bg_music(char *href, int volume);
void handleInput(SDL_Event* event, int* quit);

