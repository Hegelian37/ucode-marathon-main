#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define PLAYER_WIDTH 200
#define PLAYER_HEIGHT 200
#define PLAYER_SPEED 2

SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;
SDL_Texture* playerTexture = NULL;
SDL_Rect playerRect;

int initializeSDL() {
	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
		return 0;
	}

	window = SDL_CreateWindow("Simple Sidescroller", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
	if (window == NULL) {
		printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
		return 0;
	}

	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	if (renderer == NULL) {
		printf("Renderer could not be created! SDL_Error: %s\n", SDL_GetError());
		return 0;
	}

	int imgFlags = IMG_INIT_PNG;
	if (!(IMG_Init(imgFlags) & imgFlags)) {
		printf("SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError());
		return 0;
	}

	return 1;
}

SDL_Texture* loadTexture(const char* path) {
	SDL_Surface* loadedSurface = IMG_Load(path);
	if (loadedSurface == NULL) {
		printf("Unable to load image %s! SDL_image Error: %s\n", path, IMG_GetError());
		return NULL;
	}

	SDL_Texture* newTexture = SDL_CreateTextureFromSurface(renderer, loadedSurface);
	SDL_FreeSurface(loadedSurface);

	return newTexture;
}

void closeSDL() {
	SDL_DestroyTexture(playerTexture);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	IMG_Quit();
	SDL_Quit();
}

void handleInput(SDL_Event* event, int* quit) {
	while (SDL_PollEvent(event) != 0) {
		if (event->type == SDL_QUIT) {
			*quit = 1;
		}
	}

	const Uint8* currentKeyStates = SDL_GetKeyboardState(NULL);

	if (currentKeyStates[SDL_SCANCODE_ESCAPE]) {
		*quit = 1;
	}

	if (currentKeyStates[SDL_SCANCODE_RIGHT]) {
		playerRect.x += PLAYER_SPEED;
		SDL_Delay(5);
	}

	if (currentKeyStates[SDL_SCANCODE_LEFT]) {
		playerRect.x -= PLAYER_SPEED;
		SDL_Delay(5);
	}
}

void updateGame() {
	// Update game logic here
}

void render() {
	// Clear the renderer
	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
	SDL_RenderClear(renderer);
	SDL_Delay(5);

	// Render the player texture
	SDL_RenderCopy(renderer, playerTexture, NULL, &playerRect);

	// Present the renderer
	SDL_RenderPresent(renderer);
}

int main() {
	if (!initializeSDL()) {
		return 1;
	}

	// Load player texture
	playerTexture = loadTexture("resources/textures/char.png");
	if (playerTexture == NULL) {
		closeSDL();
		return 1;
	}

	int quit = 0;
	SDL_Event e;

	// Initialize player position
	playerRect.x = SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2;
	playerRect.y = SCREEN_HEIGHT - PLAYER_HEIGHT;
	playerRect.w = PLAYER_WIDTH;
	playerRect.h = PLAYER_HEIGHT;

	while (!quit) {
		handleInput(&e, &quit);
		updateGame();
		render();
	}

	closeSDL();
	return 0;
}

