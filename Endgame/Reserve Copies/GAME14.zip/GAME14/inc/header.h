#pragma once

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdbool.h>
#include "animation.h"

#define NUM_RESOLUTIONS 5
#define NUM_FRAMES 8
#define FRAME_DELAY 10

extern int SCREEN_WIDTH;
extern int SCREEN_HEIGHT;
extern int PLAYER_WIDTH;
extern int PLAYER_HEIGHT;
extern int DOOR_WIDTH;
extern int DOOR_HEIGHT;
extern int BG_WIDTH;
extern int PLAYER_SPEED;

extern SDL_Window* window;

extern SDL_Renderer* renderer;

extern SDL_Rect backgroundRect;
extern SDL_Rect DoorRect;
extern SDL_Rect playerRect;

extern SDL_Texture* backgroundTexture;
extern SDL_Texture* DoorTexture;
extern SDL_Texture* playerTexture;

extern Mix_Chunk* sound;
extern Mix_Music* backgroundMusic;

typedef struct {
    int width;
    int height;
} Resolution;

int initializeSDL();
void arrinit(Resolution resolutions[]);
void adapUI(int position, Resolution arr[NUM_RESOLUTIONS]);
SDL_Texture* loadTexture(const char* path);
void closeSDL();
void render();
void sound_play(char *href, int volume);
void bg_music(char *href, double volume);
void handleInput();
bool isMouseOver(SDL_Rect* rect, int mouseX, int mouseY);
int showmenu();
int loc_room();
void help_screen();

