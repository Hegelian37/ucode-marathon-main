#include "header.h"
#include "animation.h"

int currentFramePlayer = 0;
int frameCounterPlayer = 0;
int currentFrameDoor = 0;
int frameCounterDoor = 0;

int intermenu() {
	Uint32 time;
	int NUMMENU = 5;
	int x, y;
	SDL_Texture* button[5];
	SDL_Rect pos[5];
	bool selected[5] = { 0, 0, 0, 0, 0 };
	char* unclickpath[] = { "resources/textures/buttons/new_game_button.png", "resources/textures/buttons/save_button.png", "resources/textures/buttons/loadgame_button.png", "resources/textures/buttons/settings_button.png", "resources/textures/buttons/exit_button.png" };
	char* clickpath[] = { "resources/textures/buttons/new_game_button_click.png", "resources/textures/buttons/save_button_click.png", "resources/textures/buttons/loadgame_button_click.png", "resources/textures/buttons/settings_button_click.png", "resources/textures/buttons/exit_button_click.png" };
	SDL_Texture* blackoutTexture = loadTexture("resources/blackout.png");
	SDL_Rect blackoutRect;
	blackoutRect.x = 0;
	blackoutRect.y = 0;
	blackoutRect.w = SCREEN_WIDTH;
	blackoutRect.h = SCREEN_HEIGHT;
	for (int i = 0; i < NUMMENU; i++) {
		button[i] = loadTexture(unclickpath[i]);
		pos[i].h = 2 * (SCREEN_HEIGHT / 4) / NUMMENU;
		pos[i].w = 536 * pos[i].h / 200;
		pos[i].x = SCREEN_WIDTH / 2 - pos[i].w / 2;
		if (i == 0) {
			pos[i].y = SCREEN_HEIGHT / 3 - pos[i].h / 2;
		}
		else {
			pos[i].y = pos[i - 1].y + 5 * pos[i - 1].h / 4;
		}
	}
	SDL_RenderClear(renderer);
	SDL_Event event;
	while (1)
	{
		time = SDL_GetTicks();
		while (SDL_PollEvent(&event))
		{
			switch (event.type)
			{
			case SDL_QUIT:
				SDL_RenderClear(renderer);
				closeSDL();
				return 1;
			case SDL_MOUSEMOTION:
				x = event.motion.x;
				y = event.motion.y;
				for (int i = 0; i < NUMMENU; i += 1) {
					if (x >= pos[i].x && x <= pos[i].x + pos[i].w && y >= pos[i].y && y <= pos[i].y + pos[i].h)
					{
						if (!selected[i])
						{
							selected[i] = 1;
							SDL_RenderClear(renderer);
							button[i] = loadTexture(clickpath[i]);
						}
					}
					else
					{
						if (selected[i])
						{
							selected[i] = 0;
							SDL_RenderClear(renderer);
							button[i] = loadTexture(unclickpath[i]);
						}
					}
				}
				break;
			case SDL_MOUSEBUTTONDOWN:
				x = event.button.x;
				y = event.button.y;
				for (int i = 0; i < NUMMENU; i += 1) {
					if (x >= pos[i].x && x <= pos[i].x + pos[i].w && y >= pos[i].y && y <= pos[i].y + pos[i].h)
					{
						SDL_RenderClear(renderer);
						return i;
					}
				}
				break;
			case SDL_KEYDOWN:
				if (event.key.keysym.sym == SDLK_ESCAPE)
				{
					SDL_RenderClear(renderer);
					return 0;
				}
				break;
			}
		}
		SDL_RenderCopy(renderer, backgroundTexture, NULL, &backgroundRect);
		SDL_RenderCopy(renderer, playerTexture, &animationClipsPlayer[currentFramePlayer], &playerRect);
		SDL_RenderCopy(renderer, blackoutTexture, NULL, &blackoutRect);
		for (int i = 0; i < NUMMENU; i += 1) {
			SDL_RenderCopy(renderer, button[i], NULL, &pos[i]);
		}
		SDL_RenderPresent(renderer);
		if (1000 / 30 > (SDL_GetTicks() - time))
			SDL_Delay(1000 / 30 - (SDL_GetTicks() - time));
	}

	return 1;
}

void handleInput() {
	//Uint32 time;
	SDL_Event event;
	int x, y;
	while (1)
	{
		//time = SDL_GetTicks();
		while (SDL_PollEvent(&event))
		{
			switch (event.type)
			{
			case SDL_QUIT:
				return;
			case SDL_MOUSEMOTION:
				x = event.motion.x;
				y = event.motion.y;
				if (isMouseOver(&DoorRect, x, y)) {
					//SDL_DestroyTexture(DoorTexture);
					//DoorTexture = loadTexture("resources/textures/sprites/DoorAjar.png");
					frameCounterDoor++;
					if (frameCounterDoor >= FRAME_DELAY) {
						currentFrameDoor = 1;
						frameCounterDoor = 0;
					}
				}
				else {
					//SDL_DestroyTexture(DoorTexture);
					//DoorTexture = loadTexture("resources/textures/objects/Door.png");
					frameCounterDoor++;
					if (frameCounterDoor >= FRAME_DELAY) {
						currentFrameDoor = 0;
						frameCounterDoor = 0;
					}
				}
				//if (1000 / 30 > (SDL_GetTicks() - time)) SDL_Delay(1000 / 30 - (SDL_GetTicks() - time));
			case SDL_KEYDOWN:
				if (event.key.keysym.sym == SDLK_ESCAPE) {
					intermenu();
				}
			}
		}
		const Uint8* currentKeyStates = SDL_GetKeyboardState(NULL);

		//if (currentKeyStates[SDL_SCANCODE_ESCAPE]) {
		//	*quit = 1;
		//	closeSDL();
		//}

		if (currentKeyStates[SDL_SCANCODE_LEFT]) {
			if (backgroundRect.x < 0 && playerRect.x == SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2 && playerRect.x == SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2) {
				backgroundRect.x += PLAYER_SPEED;
				DoorRect.x += PLAYER_SPEED;
			}
			else if (playerRect.x > 0) {
				playerRect.x -= PLAYER_SPEED;
			}
			// Update animation frame
			frameCounterPlayer++;
			if (frameCounterPlayer >= FRAME_DELAY) {
				currentFramePlayer = (currentFramePlayer + 1) % 3 + 4;
				frameCounterPlayer = 0;
			}
		}
		else if (currentKeyStates[SDL_SCANCODE_RIGHT]) {
			if (backgroundRect.x > SCREEN_WIDTH - BG_WIDTH + PLAYER_WIDTH / 2 && playerRect.x == SCREEN_WIDTH / 2 - PLAYER_WIDTH / 2) {
				backgroundRect.x -= PLAYER_SPEED;
				DoorRect.x -= PLAYER_SPEED;
			}
			else if (playerRect.x < SCREEN_WIDTH - PLAYER_WIDTH) {
				playerRect.x += PLAYER_SPEED;
			}
			// Update animation frame
			frameCounterPlayer++;
			if (frameCounterPlayer >= FRAME_DELAY) {
				currentFramePlayer = (currentFramePlayer + 1) % 3 + 1;
				frameCounterPlayer = 0;
			}
		}
		else {
			currentFramePlayer = 0;
		}
		render();
	}
}

