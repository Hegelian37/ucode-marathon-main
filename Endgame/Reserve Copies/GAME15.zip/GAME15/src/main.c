#include "header.h"

int main() {
	if (!initializeSDL()) {
		return 1;
	}
	
	Resolution resolutions[NUM_RESOLUTIONS];
	arrinit(resolutions);

	int resol_count = 4;

	adapUI(resol_count, resolutions);

	if (resol_count == 0)
	{
		SDL_SetWindowFullscreen(window, SDL_WINDOW_FULLSCREEN);
	}
	
	switch (showmenu()) {
		case 0:
			loc_room();
			break;
		case 1:
			break;
		case 2:
			break;
		case 3:
			help_screen();
			break;
		case 4:
			break;
	}
	
	closeSDL();
	return 0;
}

