#ifndef ANIMATION_H
#define ANIMATION_H

extern int currentFramePlayer;
extern int frameCounterPlayer;
extern SDL_Rect animationClipsPlayer[];
extern int currentFrameDoor;
extern int frameCounterDoor;
extern SDL_Rect animationClipsDoor[];

#endif
